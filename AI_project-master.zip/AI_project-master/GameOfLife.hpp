//
//  GameOfLife.hpp
//  AI
//
//  Created by Rishi on 20/10/15.
//  Copyright © 2015 Rishi. All rights reserved.
//

#ifndef GameOfLife_hpp
#define GameOfLife_hpp

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <string>

#endif /* GameOfLife_hpp */
